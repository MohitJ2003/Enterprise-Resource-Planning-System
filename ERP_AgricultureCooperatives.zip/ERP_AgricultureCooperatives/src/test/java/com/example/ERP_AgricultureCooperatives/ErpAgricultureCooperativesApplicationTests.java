package com.example.ERP_AgricultureCooperatives;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErpAgricultureCooperativesApplicationTests {

	@Test
	void contextLoads() {
	}

}
