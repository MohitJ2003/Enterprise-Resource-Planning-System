package com.example.ERP_AgricultureCooperatives;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErpAgricultureCooperativesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErpAgricultureCooperativesApplication.class, args);
	}

}
